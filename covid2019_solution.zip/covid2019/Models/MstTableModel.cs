﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace covid2019.Models
{
    public class MstTableModel
    {
        public Int32 Id { get; set; }
        public String Category { get; set; }
        public String Code { get; set; }
        public String Value { get; set; }
    }
}
